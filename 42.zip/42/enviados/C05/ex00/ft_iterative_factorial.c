/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 20:08:28 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/16 12:51:39 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_iterative_factorial(int nb)
{
	int f;

	if (nb < 0)
		return (0);
	if (nb == 0)
		return (1);
	f = 1;
	while (nb >= 1)
	{
		f = f * nb;
		nb--;
	}
	return (f);
}
