/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 19:11:00 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/15 11:43:42 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_atoi(const char *str)
{
	unsigned int res;
	unsigned int negative;

	negative = 1;
	res = 0;
	while (*str == ' ' || *str == '\n' || *str == '\v' ||
	*str == '\r' || *str == '\f' || *str == '\t')
		++str;
	if (*str == '-')
		negative = -1;
	if (*str == '-' || *str == '+')
		++str;
	while (*str && *str >= 48 && *str <= 57)
	{
		res = (res * 10) + (*str - '0');
		++str;
	}
	return (res * negative);
}
