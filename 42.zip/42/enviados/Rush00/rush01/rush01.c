/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: angarcia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/29 12:41:11 by angarcia          #+#    #+#             */
/*   Updated: 2020/11/29 15:16:14 by angarcia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c);

void	rush(int x, int y)
{
	int a;
	int b;

	a = 1;
	b = 1;
	while (a <= y)
	{
		while (b <= x)
		{
			if ((a == 1 && b == 1) || (a == y && b == x && x > 1 && y > 1))
				ft_putchar('/');
			else if ((a == y && b == 1) || (a == 1 && b == x))
				ft_putchar('\\');
			else if (((a == 1 || a == y) && (b > 1 && b < x))
				|| ((a > 1 && a < y) && (b == 1 || b == x)))
				ft_putchar('*');
			else
				ft_putchar(' ');
			b++;
		}
		ft_putchar('\n');
		b = 1;
		a++;
	}
}
