/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/10 09:14:17 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/15 09:10:11 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int i;
	unsigned int j;

	i = 0;
	j = 0;
	while (dest[j])
		j++;
	while (src[i])
	{
		if (j < size - 1)
			dest[j] = src[i];
		j++;
		i++;
	}
	dest[j - 1] = '\0';
	return (j);
}

int	main(void)
{
	char a[] = "sdfb";
	char b[] = "ba";

	printf("%u\n", ft_strlcat(a, b, 12));
	return (0);
}
