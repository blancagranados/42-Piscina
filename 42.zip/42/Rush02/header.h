/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 11:02:44 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/13 11:23:36 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H

typedef struct  s_list
{
   int n;
   char *ltr;
}               t_list;
int		ft_strlen(char *str);
void	ft_putstr(char *str);
char *ft_strdup(char *src);
unsigned int	ft_atoi(const char *str);
char	*ft_getn(int a);
char	*ft_getltr(int b, char *c);
t_list *dict(char *file);
#endif
