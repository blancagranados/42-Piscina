/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_funciones.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/12 20:59:45 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/13 20:40:15 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

void	ft_putstr(char *str)
{
	int n;

	n = 0;
	while (str[n])
	{
		ft_putchar(str[n]);
		n++;
	}
}

char	*ft_strdup(char *src)
{
	int i;
	int n;
	char *res;

	n = 0;
	while (src[n])
		n++;
	res = (char*)malloc(n + 1);
	if (res != NULL)
	{
		i = 0;
	while (src[i])
	{
		res[i] = src[i];
		i++;
	}
	res[i] = '\0';
	}
	return (res);
}

unsigned int	ft_atoi(const char *str)
{
	unsigned int res;
	unsigned int negative;

	negative = 1;
	res = 0;
	while (*str == ' ' || *str == '\n' || *str == '\v' ||
	*str == '\r' || *str == '\f' || *str == '\t')
		++str;
	if (*str == '-')
		negative = -1;
	if (*str == '-' || *str == '+')
		++str;
	while (*str && *str >= 48 && *str <= 57)
	{
		res = (res * 10) + (*str - '0');
		++str;
	}
	return (res * negative);
}
