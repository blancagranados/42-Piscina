/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dic.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 10:37:20 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/13 11:23:23 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>

char	*ft_getn(int a)
{
	int i;
	char c[1];
	char *res;

	i = 0;
	if(!(res = malloc(sizeof(char) * 128)))
		exit(1);
	read(a, c, 1);
	while(c[0] == '\n')
		read(a, c, 1);
	while(c[0] >= 48 && c[0] <= 57)
	{
		res[i] = c[0];
		read(a, c, 1);
		i++;
	}
	return(res);
}

char	*ft_getltr(int b, char *c)
{
	int i;
	char *res;

	i = 0;
	if(!(res = malloc(sizeof(char) * 128)))
		exit(1);
	read(b, c, 1);
	while(c[0] != '\n')
	{
		res[i] = c[0];
		read(b, c, 1);
		i++;
	}
	return(res);
}

t_list *dict(char *file)
{
	int i;
	int fd;
	char c[1];
	t_list	*tab;
	char	*temp;

	i = 0;
	fd = open(file, O_RDONLY);
	if(fd == -1 || !(tab = malloc(sizeof(t_list) * 33)))
		exit(1);
	while(i < 32)
	{
		tab[i].n = ft_atoi(ft_getn(fd));
		read(fd, c, 1);
		while (c[0] == ' ')
			read(fd, c, 1);
		if (c == ':')
			read(fd, c, 1);
		temp = ft_getltr(fd, c);
		tab[i].ltr = ft_strdup(temp);
		free(temp);
		i++;
	}
	close(fd);
	return (tab);
}
