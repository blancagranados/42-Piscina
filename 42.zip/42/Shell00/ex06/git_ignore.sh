git ls-files -i --exclude -standard -o

