/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/08 11:07:39 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/11 13:42:56 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int i;

	i = 0;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

/*int		main(void)
{
	char dest[3];
	char *src = "22222";
	
	ft_strncpy(dest ,src, 2);
	write(1, &dest, 2);
	//printf("%s\n", ft_strncpy(dest ,src, 2));
	return 0;
}*/

int		main(void)
{
	int a;
	char src[] = "222222";
	a = 0;
	ft_strncpy(&src);
	while(src[a] != '\0')
	{
		write(1, &src[a], 1);
		a++;
	}
}
