/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 21:55:55 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/15 15:45:07 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_iterative_power(int nb, int power)
{
	int i;
	int f;

	if (power < 0)
		return (0);
	if (power == 0 || (power == 0 && nb == 0))
		return (1);
	i = 0;
	f = 1;
	while (i < power)
	{
		f = f * nb;
		i++;
	}
	return (f);
}

int	main(void)
{
	printf("%d\n", ft_iterative_power(4, 2));
	return (0);
}
