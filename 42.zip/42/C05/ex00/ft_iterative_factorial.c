/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 20:08:28 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/15 15:44:18 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_iterative_factorial(int nb)
{
	int f;

	if (nb < 0)
		return (0);
	if (nb == 0)
		return (1);
	f = 1;
	while (nb >= 1)
	{
		f = f * nb;
		nb--;
	}
	return (f);
}

int main(void)
{
	int a;

	printf("%d\n", ft_iterative_factorial(4));
	return (0);
}
