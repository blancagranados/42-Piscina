/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bgranado <bgranado@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 17:52:13 by bgranado          #+#    #+#             */
/*   Updated: 2020/12/17 11:49:56 by bgranado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_strcmp(char *x, char *y)
{
	int i;

	i = 0;
	while ((x[i] != '\0') && (y[i] != '\0') && (x[i] == y[i]))
		i++;
	return (x[i] - y[i]);
}

void	ft_params(char **argv)
{
	int i;
	int j;

	i = 1;
	while (argv[i])
	{
		j = 0;
		while (argv[i][j])
		{
			write(1, &argv[i][j], 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

int		main(int argc, char **argv)
{
	int		a;
	int		b;
	char	*c;

	a = 1;
	while (a < argc)
	{
		b = 1;
		while (b < argc)
		{
			if (ft_strcmp(argv[a], argv[b]) < 0)
			{
				c = argv[a];
				argv[a] = argv[b];
				argv[b] = c;
			}
			b++;
		}
		a++;
	}
	ft_params(argv);
}
