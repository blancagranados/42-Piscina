/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   struct2.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amolina- <amolina-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/15 20:27:09 by amolina-          #+#    #+#             */
/*   Updated: 2020/12/15 20:38:32 by amolina-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRUCT2_H
# define STRUCT2_H

struct		s_var2
{
	int		fd;
	int		size;
	char	*buffer;
	char	**table;
	char	*array_of_chars;
	int		*maximum;
};

#endif
